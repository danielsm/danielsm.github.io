#ifndef Fila_H
#define Fila_H
#define TRUE 1
#define FALSE 0

//Defina a estrutura do pacote


typedef struct {
        int maxItens;
        //TIPO * itens; vetor que guardara os pacotes
        int fim;
}Fila;
        
Fila * qCreate(int max);

int qDestroy(Fila *q);

int qEnFila(Fila *q,void * item);

void  * qDeFila(Fila *q);

void  * qFirst (Fila *q);

int qIsEmpty(Fila *q);

#endif
