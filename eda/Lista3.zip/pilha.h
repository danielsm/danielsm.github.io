#ifndef PILHA_H
#define PILHA_H
#define TRUE 1
#define FALSE 0


typedef struct {
		int max;
        char *string;
        int top;
}Pilha;

//cria pilha
Stack * createP(int max);

//destroi pilha
int destroyP(Stack *s);

//coloca item no topo da pilha
int push (Stack *s,char item);

//retira o item do topo e retorna ele
char pop (Stack *s);

//consulta topo da pilha
char top (Stack *s);

//retorna V se a pilha está vazia e F caso contrário
int pilhaIsEmpty (Stack *s);

#endif