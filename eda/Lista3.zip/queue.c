#include "queue.h"
#include <stdio.h>
#include <stdlib.h>

Queue * qCreate (int max){
  /*  
  Se numero de itens maior que 0 
    Cria uma fila
    Se deu Certo
      Cria um Vetor dentro da fila do tamanho max
      Se deu Certo
        atribui os valores aos campos da fila
        Retorna a fila com a vetor dentro
      Se Não
        Destroi a fila
      Fim Se
    Fim Se
  Fim Se
  Retorna Deu Errado*/
                           
}


int qDestroy (Queue *q){
    /*
    Se fila tá vazia
      toca fogo no vetor
      Toca fogo em fila
      Retorna V
    Se Não
      Retorna F
    Fim Se
  */
}


int qEnqueue(Queue *q,void * item){
    /*
    Se fila é válida
      Se fila tem um vetor válido
        Se tem espaço no vetor
          coloca item atras 
          anota espaço preenchido
          Retorna V
        Fim Se
      Fim Se
    Fim Se
    Retorna F
  */
}

void * qDequeue (Queue *q){
    /*
  se a fila é válida
    se o vetor é válido
      Se fila não está vazia
        Guarda o primeiro
        rearranja a fila
        Decrementa o final da fila
        Retorna o cara que estava guardado
      Fim se
    Fim se
  Fim se
  RETORNA NULL   
      */
}


void * qFirst(Queue *q){
     /*
  se a fila é válida
    se o vetor é válido
      Se fila não está vazia
        Retorna o primeiro
      Fim se
    Fim se
  Fim se
  RETORNA NULL   
  */  
}


int qIsEmpty(Queue *q){
      /*
  se a fila é válida
    se o vetor é válido
      Se fila está vazia
        Retorna V
      Fim se
    Fim se
  Fim se
  RETORNA F
  */
}
