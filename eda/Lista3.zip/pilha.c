#include "stack.h"
#include <stdio.h>
#include <stdlib.h>

Stack * createP(int max) {
  /*
  Se numero de itens maior que 0
    Cria uma pilha
    Se deu Certo
      Cria um Vetor dentro da pilha do tamanho max
      Se deu Certo
        atribui os valores aos campos das pilhas
        Retorna a pilha com a vetor dentro
      Se Não
        Destroi a pilha
      Fim Se
    Fim Se
  Fim se
  Retorna Deu Errado*/
}

  
int destroyP (Stack *s){
    /*
    Se pilha tá vazia
      toca fogo no vetor
      Toca fogo em pilha
      Retorna V
    Se Não
      Retorna F
    Fim Se
  */
}


int push (Stack *s,void * item){
    /*
    Se pilha é válida
      Se pilha tem um vetor válido
        Se tem espaço no vetor
          coloca item no primeiro espaço vazio
          anota espaço preenchido
          Retorna V
        Fim Se
      Fim Se
    Fim Se
    Retorna F
  */
}


char pop (Stack *s){
  /*
  se a pilha é válida
    se o vetor é válido
      Se pilha não está vazia
        Guarda o cara do topo
        Decrementa o topo
        Retorna o cara que estava guardado
      Fim se
    Fim se
  Fim se
  RETORNA NULL   
      */
}

char top (Stack *s){
  /*
  se a pilha é válida
    se o vetor é válido
      Se pilha não está vazia
        Retorna o cara topo
      Fim se
    Fim se
  Fim se
  RETORNA NULL   
  */
     
}


int pilhaIsEmpty (Stack *s){
  /*
  se a pilha é válida
    se o vetor é válido
      Se pilha está vazia
        Retorna V
      Fim se
    Fim se
  Fim se
  RETORNA F
  */
}
